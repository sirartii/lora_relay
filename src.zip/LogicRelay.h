//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#ifndef __OPP_LORA_RELAY_OFFICIAL_LOGICRELAY_H_
#define __OPP_LORA_RELAY_OFFICIAL_LOGICRELAY_H_

#include <omnetpp.h>

using namespace omnetpp;

namespace opp_lora_relay_official {

/**
 * TODO - Generated class
 */
class LogicRelay : public cSimpleModule, public cListener
{

  protected:
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
    //virtual void receiveSignal(cComponent *src, simsignal_t id, cObject *value, cObject *details) override;
    //virtual void receiveSignal(cComponent *src, simsignal_t id, intval_t value, cObject *details) override;
    //virtual void receiveSignal(cComponent *src, simsignal_t id, bool value, cObject *details) override;
    virtual void receiveSignal(cComponent *src, simsignal_t id, double value, cObject *details) override;
  private:
    simtime_t lastPacketReceive;
    simsignal_t wakeupRelay;
    float RXR_delay;

};

} //namespace

#endif
